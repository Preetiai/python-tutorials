a = 50
b = 3

print("The value of", a, "+", 3, "is: ", a + b)
print("The value of", a, "-", 3, "is: ", a - b)
print("The value of", a, "*", 3, "is: ", a * b)
print("The value of", a, "/", 3, "is: ", a / b)
