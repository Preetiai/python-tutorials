## Exercise 1 - Create a Calculator Solution
Create a calculator capable of performing addition, subtraction, multiplication and division operations on two numbers. Your program should format the output in a readable manner!

## [Next Lesson>>](https://replit.com/@codewithharry/09-Day9-Typecasting-in-Python)